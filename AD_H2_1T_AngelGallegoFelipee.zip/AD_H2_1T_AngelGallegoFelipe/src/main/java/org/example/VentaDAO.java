package org.example;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class VentaDAO {

    public void obtenerVentasTotales() throws SQLException {
        String sql = "SELECT SUM(Venta.cantidad * Producto.precio) AS ventas_totales FROM Venta JOIN Producto ON Venta.idProducto = Producto.id";
        try (Connection conn = ConexionBaseDatos.obtenerConexion();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            if (rs.next()) {
                double ventasTotales = rs.getDouble("ventas_totales");
                System.out.printf("Ventas totales: %.2f%n", ventasTotales);
            }
        }
    }

    public void obtenerVentasUltimosTresMeses() throws SQLException {
        String sql = "SELECT SUM(Venta.cantidad * Producto.precio) AS ventas_ultimos_tres_meses FROM Venta JOIN Producto ON Venta.idProducto = Producto.id WHERE Venta.fecha >= DATE_SUB(CURDATE(), INTERVAL 3 MONTH)";
        try (Connection conn = ConexionBaseDatos.obtenerConexion();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            if (rs.next()) {
                double ventasUltimosTresMeses = rs.getDouble("ventas_ultimos_tres_meses");
                System.out.printf("Ventas de los últimos 3 meses: %.2f%n", ventasUltimosTresMeses);
            }
        }
    }

    public void obtenerTopCincoClientes() throws SQLException {
        String sql = "SELECT Cliente.id, Cliente.nombre, SUM(Venta.cantidad * Producto.precio) AS total_gastado FROM Venta JOIN Cliente ON Venta.idCliente = Cliente.id JOIN Producto ON Venta.idProducto = Producto.id GROUP BY Cliente.id, Cliente.nombre ORDER BY total_gastado DESC LIMIT 5";
        try (Connection conn = ConexionBaseDatos.obtenerConexion();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            System.out.println("\nTop 5 clientes que más gastan:");
            while (rs.next()) {
                int idCliente = rs.getInt("id");
                String nombreCliente = rs.getString("nombre");
                double totalGastado = rs.getDouble("total_gastado");
                System.out.printf("ID: %d, Nombre: %s, Total gastado: %.2f%n", idCliente, nombreCliente, totalGastado);
            }
        }
    }

    public void registrarVenta(int idCliente, int idProducto, int cantidad) throws SQLException {
        String sql = "INSERT INTO Venta (idCliente, idProducto, cantidad, fecha) VALUES (?, ?, ?, NOW())";
        try (Connection conn = ConexionBaseDatos.obtenerConexion();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, idCliente);
            stmt.setInt(2, idProducto);
            stmt.setInt(3, cantidad);
            stmt.executeUpdate();
            System.out.println("Venta registrada exitosamente.");
        }
    }

    public void listarVentas() throws SQLException {
        String sql = "SELECT Venta.id, Cliente.nombre AS nombre_cliente, Producto.nombre AS nombre_producto, Venta.cantidad, Venta.fecha FROM Venta JOIN Cliente ON Venta.idCliente = Cliente.id JOIN Producto ON Venta.idProducto = Producto.id";
        try (Connection conn = ConexionBaseDatos.obtenerConexion();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            System.out.println("\n=== Listado de Ventas ===");
            while (rs.next()) {
                int id = rs.getInt("id");
                String nombreCliente = rs.getString("nombre_cliente");
                String nombreProducto = rs.getString("nombre_producto");
                int cantidad = rs.getInt("cantidad");
                String fecha = rs.getString("fecha");

                System.out.printf("ID: %d, Cliente: %s, Producto: %s, Cantidad: %d, Fecha: %s%n",
                        id, nombreCliente, nombreProducto, cantidad, fecha);
            }
        }
    }
}