package org.example;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ClienteDAO {

    // Método para agregar un nuevo cliente
    public void agregarCliente(String nombre, String direccion, String telefono, String email) {
        String sql = "INSERT INTO Cliente (nombre, direccion, telefono, email) VALUES (?, ?, ?, ?)";

        try (Connection conn = ConexionBaseDatos.obtenerConexion();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, nombre);
            stmt.setString(2, direccion);
            stmt.setString(3, telefono);
            stmt.setString(4, email);
            stmt.executeUpdate();
            System.out.println("Cliente agregado exitosamente.");

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Método para actualizar un cliente existente
    public void actualizarCliente(int id, String nombre, String direccion, String telefono, String email) {
        String sql = "UPDATE Cliente SET nombre = ?, direccion = ?, telefono = ?, email = ? WHERE id = ?";

        try (Connection conn = ConexionBaseDatos.obtenerConexion();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, nombre);
            stmt.setString(2, direccion);
            stmt.setString(3, telefono);
            stmt.setString(4, email);
            stmt.setInt(5, id);
            stmt.executeUpdate();
            System.out.println("Cliente actualizado exitosamente.");

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Método para eliminar un cliente
    public void eliminarCliente(int id) throws SQLException {
        Connection conexion = ConexionBaseDatos.obtenerConexion();
        try {
            // Eliminar filas relacionadas en la tabla Venta
            String sqlEliminarVentas = "DELETE FROM Venta WHERE idCliente = ?";
            PreparedStatement stmtEliminarVentas = conexion.prepareStatement(sqlEliminarVentas);
            stmtEliminarVentas.setInt(1, id);
            stmtEliminarVentas.executeUpdate();

            // Eliminar el Cliente
            String sqlEliminarCliente = "DELETE FROM Cliente WHERE id = ?";
            PreparedStatement stmtEliminarCliente = conexion.prepareStatement(sqlEliminarCliente);
            stmtEliminarCliente.setInt(1, id);
            stmtEliminarCliente.executeUpdate();
            System.out.println("Cliente eliminado exitosamente.");
        } finally {
            if (conexion != null) {
                conexion.close();
            }
        }
    }

    // Método para listar todos los clientes
    public void listarClientes() {
        String sql = "SELECT * FROM Cliente";

        try (Connection conn = ConexionBaseDatos.obtenerConexion();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            System.out.println("\n=== Listado de Clientes ===");
            while (rs.next()) {
                int id = rs.getInt("id");
                String nombre = rs.getString("nombre");
                String direccion = rs.getString("direccion");
                String telefono = rs.getString("telefono");
                String email = rs.getString("email");

                System.out.printf("ID: %d, Nombre: %s, Dirección: %s, Teléfono: %s, Email: %s%n",
                        id, nombre, direccion, telefono, email);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}