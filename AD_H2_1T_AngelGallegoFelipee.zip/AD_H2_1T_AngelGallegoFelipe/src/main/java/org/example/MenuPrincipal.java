package org.example;

import java.sql.SQLException;
import java.util.Scanner;

public class MenuPrincipal {

    private static ProductoDAO productoDAO = new ProductoDAO();
    private static ClienteDAO clienteDAO = new ClienteDAO();
    private static VentaDAO ventaDAO = new VentaDAO();
    private static Scanner scanner = new Scanner(System.in);

    public static void mostrarMenu() throws SQLException {
        int opcion = 0;

        do {
            System.out.println("\n=== Menú Principal ===");
            System.out.println("1. Gestión de Inventario");
            System.out.println("2. Gestión de Clientes");
            System.out.println("3. Ventas y Facturación");
            System.out.println("4. Consultas y Reportes");
            System.out.println("5. Salir");
            System.out.print("Seleccione una opción: ");

            opcion = scanner.nextInt();
            scanner.nextLine(); // Limpiar el buffer

            switch (opcion) {
                case 1:
                    menuInventario();
                    break;
                case 2:
                    menuClientes();
                    break;
                case 3:
                    menuVentas();
                    break;
                case 4:
                    menuReportes();
                    break;
                case 5:
                    System.out.println("Saliendo del sistema...");
                    break;
                default:
                    System.out.println("Opción no válida, por favor intente de nuevo.");
            }
        } while (opcion != 5);
    }

    private static void menuInventario() {
        int opcion = 0;

        do {
            System.out.println("\n=== Gestión de Inventario ===");
            System.out.println("1. Agregar producto");
            System.out.println("2. Actualizar producto");
            System.out.println("3. Eliminar producto");
            System.out.println("4. Listar productos");
            System.out.println("5. Regresar al Menú Principal");
            System.out.print("Seleccione una opción: ");

            opcion = scanner.nextInt();
            scanner.nextLine();

            switch (opcion) {
                case 1:
                    System.out.print("Ingrese el nombre del producto: ");
                    String nombre = scanner.nextLine();
                    System.out.print("Ingrese la categoría del producto: ");
                    String categoria = scanner.nextLine();
                    System.out.print("Ingrese el precio del producto: ");
                    double precio = scanner.nextDouble();
                    System.out.print("Ingrese la cantidad del producto: ");
                    int cantidad = scanner.nextInt();
                    scanner.nextLine();
                    productoDAO.agregarProducto(nombre, categoria, precio, cantidad);
                    break;
                case 2:
                    System.out.print("Ingrese el ID del producto a actualizar: ");
                    int id = scanner.nextInt();
                    scanner.nextLine();
                    System.out.print("Ingrese el nuevo nombre del producto: ");
                    nombre = scanner.nextLine();
                    System.out.print("Ingrese la nueva categoría del producto: ");
                    categoria = scanner.nextLine();
                    System.out.print("Ingrese el nuevo precio del producto: ");
                    precio = scanner.nextDouble();
                    System.out.print("Ingrese la nueva cantidad del producto: ");
                    cantidad = scanner.nextInt();
                    scanner.nextLine();
                    productoDAO.actualizarProducto(id, nombre, categoria, precio, cantidad);
                    break;
                case 3:
                    System.out.print("Ingrese el ID del producto a eliminar: ");
                    id = scanner.nextInt();
                    scanner.nextLine();
                    productoDAO.eliminarProducto(id);
                    break;
                case 4:
                    productoDAO.listarProductos();
                    break;
                case 5:
                    System.out.println("Regresando al Menú Principal...");
                    break;
                default:
                    System.out.println("Opción no válida, por favor intente de nuevo.");
            }
        } while (opcion != 5);
    }

    private static void menuClientes() throws SQLException {
        int opcion = 0;

        do {
            System.out.println("\n=== Gestión de Clientes ===");
            System.out.println("1. Agregar cliente");
            System.out.println("2. Actualizar cliente");
            System.out.println("3. Eliminar cliente");
            System.out.println("4. Listar clientes");
            System.out.println("5. Regresar al Menú Principal");
            System.out.print("Seleccione una opción: ");

            opcion = scanner.nextInt();
            scanner.nextLine();

            switch (opcion) {
                case 1:
                    System.out.print("Ingrese el nombre del cliente: ");
                    String nombre = scanner.nextLine();
                    System.out.print("Ingrese la dirección del cliente: ");
                    String direccion = scanner.nextLine();
                    System.out.print("Ingrese el teléfono del cliente: ");
                    String telefono = scanner.nextLine();
                    System.out.print("Ingrese el email del cliente: ");
                    String email = scanner.nextLine();
                    clienteDAO.agregarCliente(nombre, direccion, telefono, email);
                    break;
                case 2:
                    System.out.print("Ingrese el ID del cliente a actualizar: ");
                    int id = scanner.nextInt();
                    scanner.nextLine();
                    System.out.print("Ingrese el nuevo nombre del cliente: ");
                    nombre = scanner.nextLine();
                    System.out.print("Ingrese la nueva dirección del cliente: ");
                    direccion = scanner.nextLine();
                    System.out.print("Ingrese el nuevo teléfono del cliente: ");
                    telefono = scanner.nextLine();
                    System.out.print("Ingrese el nuevo email del cliente: ");
                    email = scanner.nextLine();
                    clienteDAO.actualizarCliente(id, nombre, direccion, telefono, email);
                    break;
                case 3:
                    System.out.print("Ingrese el ID del cliente a eliminar: ");
                    id = scanner.nextInt();
                    scanner.nextLine();
                    clienteDAO.eliminarCliente(id);
                    break;
                case 4:
                    clienteDAO.listarClientes();
                    break;
                case 5:
                    System.out.println("Regresando al Menú Principal...");
                    break;
                default:
                    System.out.println("Opción no válida, por favor intente de nuevo.");
            }
        } while (opcion != 5);
    }

    private static void menuVentas() throws SQLException {
        int opcion = 0;

        do {
            System.out.println("\n=== Ventas y Facturación ===");
            System.out.println("1. Registrar venta");
            System.out.println("2. Listar ventas");
            System.out.println("3. Regresar al Menú Principal");
            System.out.print("Seleccione una opción: ");

            opcion = scanner.nextInt();
            scanner.nextLine();

            switch (opcion) {
                case 1:
                    System.out.print("Ingrese el ID del cliente: ");
                    int idCliente = scanner.nextInt();
                    System.out.print("Ingrese el ID del producto: ");
                    int idProducto = scanner.nextInt();
                    System.out.print("Ingrese la cantidad vendida: ");
                    int cantidadVendida = scanner.nextInt();
                    scanner.nextLine();
                    ventaDAO.registrarVenta(idCliente, idProducto, cantidadVendida);
                    break;
                case 2:
                    ventaDAO.listarVentas();
                    break;
                case 3:
                    System.out.println("Regresando al Menú Principal...");
                    break;
                default:
                    System.out.println("Opción no válida, por favor intente de nuevo.");
            }
        } while (opcion != 3);
    }

    private static void menuReportes() throws SQLException {
        int opcion = 0;

        do {
            System.out.println("\n=== Consultas y Reportes ===");
            System.out.println("1. Ventas totales");
            System.out.println("2. Ventas de los últimos 3 meses");
            System.out.println("3. Top 5 clientes que más gastan");
            System.out.println("4. Regresar al Menú Principal");
            System.out.print("Seleccione una opción: ");

            opcion = scanner.nextInt();
            scanner.nextLine();

            switch (opcion) {
                case 1:
                    ventaDAO.obtenerVentasTotales();
                    break;
                case 2:
                    ventaDAO.obtenerVentasUltimosTresMeses();
                    break;
                case 3:
                    ventaDAO.obtenerTopCincoClientes();
                    break;
                case 4:
                    System.out.println("Regresando al Menú Principal...");
                    break;
                default:
                    System.out.println("Opción no válida, por favor intente de nuevo.");
            }
        } while (opcion != 4);
    }

    public static void main(String[] args) throws SQLException {
        try {
            mostrarMenu();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
}
