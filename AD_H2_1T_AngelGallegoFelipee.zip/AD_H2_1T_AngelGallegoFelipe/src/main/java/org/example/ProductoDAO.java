package org.example;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ProductoDAO {

    // Método para agregar un nuevo producto
    public void agregarProducto(String nombre, String categoria, double precio, int cantidad) {
        String sql = "INSERT INTO Producto (nombre, categoria, precio, cantidad) VALUES (?, ?, ?, ?)";

        try (Connection conn = ConexionBaseDatos.obtenerConexion();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, nombre);
            stmt.setString(2, categoria);
            stmt.setDouble(3, precio);
            stmt.setInt(4, cantidad);
            stmt.executeUpdate();
            System.out.println("Producto agregado exitosamente.");

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Método para actualizar un producto existente
    public void actualizarProducto(int id, String nombre, String categoria, double precio, int cantidad) {
        String sql = "UPDATE Producto SET nombre = ?, categoria = ?, precio = ?, cantidad = ? WHERE id = ?";

        try (Connection conn = ConexionBaseDatos.obtenerConexion();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, nombre);
            stmt.setString(2, categoria);
            stmt.setDouble(3, precio);
            stmt.setInt(4, cantidad);
            stmt.setInt(5, id);
            stmt.executeUpdate();
            System.out.println("Producto actualizado exitosamente.");

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Método para eliminar un producto
    public void eliminarProducto(int id) {
        String sql = "DELETE FROM Producto WHERE id = ?";

        try (Connection conn = ConexionBaseDatos.obtenerConexion();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);
            stmt.executeUpdate();
            System.out.println("Producto eliminado exitosamente.");

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Método para listar todos los productos
    public void listarProductos() {
        String sql = "SELECT * FROM Producto";

        try (Connection conn = ConexionBaseDatos.obtenerConexion();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            System.out.println("\n=== Listado de Productos ===");
            while (rs.next()) {
                int id = rs.getInt("id");
                String nombre = rs.getString("nombre");
                String categoria = rs.getString("categoria");
                double precio = rs.getDouble("precio");
                int cantidad = rs.getInt("cantidad");

                System.out.printf("ID: %d, Nombre: %s, Categoría: %s, Precio: %.2f, Cantidad: %d%n",
                        id, nombre, categoria, precio, cantidad);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Método para listar productos con stock por debajo de un umbral especificado
    public void listarProductosBajoStock(int umbral) {
        String sql = "SELECT * FROM Producto WHERE cantidad < ?";

        try (Connection conn = ConexionBaseDatos.obtenerConexion();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, umbral);
            ResultSet rs = stmt.executeQuery();

            System.out.println("\n=== Productos con Bajo Stock ===");
            while (rs.next()) {
                int id = rs.getInt("id");
                String nombre = rs.getString("nombre");
                String categoria = rs.getString("categoria");
                double precio = rs.getDouble("precio");
                int cantidad = rs.getInt("cantidad");

                System.out.printf("ID: %d, Nombre: %s, Categoría: %s, Precio: %.2f, Cantidad: %d%n",
                        id, nombre, categoria, precio, cantidad);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
